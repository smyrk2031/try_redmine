class AddDefaultPrintableTemplate < ActiveRecord::Migration[6.1]

  def up
    # deprecated
  end

  def down
  end

end
