/*
 * COMMON
 * = require easy_gantt_pro/common
 * = require easy_gantt_pro/sorting
 * = require easy_gantt_pro/email_silencer
 * = require easy_gantt_pro/delayed_issues
 *
 * PROJECT SPECIFIC
 * = require easy_gantt_pro/baseline
 * = require easy_gantt_pro/add_task
 * = require easy_gantt_pro/critical
*/
